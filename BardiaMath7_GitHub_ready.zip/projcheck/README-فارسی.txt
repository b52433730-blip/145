پروژهٔ بردیا آماره — ریاضی هفتم

محتویات:
- app/src/main/assets/index.html : برنامهٔ آموزشی تحت WebView
- app/src/main/assets/کتاب_ریاضی_هفتم.pdf : فایل PDF کتاب
- app/src/main/assets/پوستر_بردیا_آماره.jpg : پوستر پروژه

نکتهٔ ساخت:
این ZIP نسخهٔ سورسِ به‌روزشده است، نه APK آماده. پروژهٔ اولیه Gradle Wrapper (فایل gradlew و پوشهٔ gradle/wrapper شامل gradle-wrapper.jar و gradle-wrapper.properties) ندارد. برای ساخت قابل تکرار باید Wrapper معتبر به پروژه اضافه و پروژه با Android Gradle Plugin 8.5.2 و JDK 17 همگام‌سازی شود.

محدودیت فعلی:
HTML به PDF و پوستر با نام‌های بالا لینک می‌دهد و فایل‌ها در assets قرار گرفته‌اند. نمایش PDF در WebView اندروید به‌صورت مستقیم تضمین‌شده نیست و برای تجربهٔ بهتر باید بازکردن PDF با برنامهٔ مشاهده‌گر PDF در مرحلهٔ بعد پیاده‌سازی شود.
